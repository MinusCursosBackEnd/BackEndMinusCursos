const express = require('express');
const router = express.Router();
const Curso = require('../models/cursos');
const mongoose = require('mongoose');

//Rotas para adicionar cursos
router.post('/', (req, res, next) =>{

    const curso = new Curso({
        _id: new mongoose.Types.ObjectId(),
        titulo: req.body.titulo,
        descricao: req.body.descricao,
        preco:req.body.preco
    });
    curso.save()
    .then(result =>{
        res.status(201).json({
            produtoCriado: curso
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

//Listando um unico registro
router.get('/:cursoId', (req, res, next)=>{
    const id = req.params.produtoId;
    Curso.findById(id)
    .exec()
    .then(doc => {
        res.status(200).json(doc);
    })
    .catch(err => {
        res.status(500).json({error:err});
    })
});

//rota para delete
router.delete('/:cursoId', (req, res, next)=>{
    const id = req.params.cursoId;
    Curso.deleteOne({_id:id})
    .exec()
    .then(doc => {
        res.status(200).json(doc);
    })
    .catch(err => {
        res.status(500).json({error:err});
    })
});

//Rota para editar
router.put('/:cursoId', (req, res, next) =>{
    const id = req.params.cursoId;
    const curso = new Curso({
        _id: req.params.id,
        titulo: req.body.titulo,
        descricao: req.body.descricao,
        preco:req.body.preco
    });
        Curso.updateOne({_id:id}, curso)
    .exec()
    .then(result =>{
        res.status(201).json({
            message: 'atualizado com sucesso',
            cursoatualizado: curso
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

 //atualizar curso
 router.put('/:cusoId', (req, res, next)=>{
    const id = req.params.cursoUpdate;
    const curso = req.params.body;
    Curso.findByIdAndUpdate(id,req.body,{new:true})
    .exec()
    .then(doc => {
        res.status(200).json({
            message: "Curso atualizado com sucesso.",
            cursoAtualizado: doc
        });
    })
    .catch(err =>{
        res.status(500).json({error:err});
    })
  
  });
  //listar produtos
  router.get('/cursos', function(req, res){
    Curso.find().then((Cursos) => {
        res.render("admin/cursos", {cursos: cursos})
    }).catch((err) => {
        req.flash("error_msg", "Houve um erro ao listar as categorias")
        res.redirect("/admin")
    })    
})

module.exports = router;